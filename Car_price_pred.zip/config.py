import os

CSV_FILE_PATH = os.path.join(os.getcwd(),r"CSV_file\out.csv")

MODEL_FILE_PATH = os.path.join(os.getcwd(),"linear_reg.pkl")

PROJECT_FILE_PATH = os.path.join(os.getcwd(),"project_data.json")

PORT_NUMBER = 5004
